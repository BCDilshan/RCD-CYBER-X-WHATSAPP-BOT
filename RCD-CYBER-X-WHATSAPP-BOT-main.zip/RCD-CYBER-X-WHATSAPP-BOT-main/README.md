# CYBER-X WHATSAPP BOT

<p align = center>   <img src="https://telegra.ph/file/b35562cb0b662c1d24a73.jpg" alt="GIF" width="600" height="300"/> </p>

<p align  = center> <a href="#"><img title="CYBER-X WHATSAPP BOT" src="https://img.shields.io/badge/CYBER-X WhatsApp Bot-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a> </p>


## Authors

- [@DARKALPHAXTEAM](https://www.github.com/darkalphaxteam)

## Support Group

- [Join (Only Access for Bots) ](https://chat.whatsapp.com/IZhmddusPM41KkDXZkeRio)

## Own

[![MIT License](https://img.shields.io/badge/License-MIT-green.svg)](https://choosealicense.com/licenses/mit/)
[![GPLv3 License](https://img.shields.io/badge/License-GPL%20v3-yellow.svg)](https://opensource.org/licenses/)
[![AGPL License](https://img.shields.io/badge/license-AGPL-blue.svg)](http://www.gnu.org/licenses/agpl-3.0)


## Heroku Deployment

1. Scan QR - [Click here](https://gpt-qr-web-scaner.onrender.com/cyber-x.html)

2. Fork the Repo - [Click here](https://github.com/darkalphaxteam/CYBER-X-WHATSAPP-BOT/fork)

3. Go app.json and Change "repostory" Url's user name to your user name ( Line 04 )

4. Create your own Heroku template Link `https://heroku.com/deploy?template={Your repo Link}`

5. Deploy now without Heroku Suspend


## Features

- Group Commands
- Download Commands
- 24 Work time
- Full Costermizable
- Free Deployments
- Latest Baileys Using
- 2x Respond Speed
- Amazing Commands


## Support

For support, email darkalphaxteamofficial@gmail.com or After deploying the bot you can join the CYBER-X support group by using the `.joinsup` command…


## Feedback

If you have any feedback, please reach out to us at darkalphaxteamofficial@gmail.com


## Environment Variables

To run this project, you will need to add the following environment variables to your .env file

`SESSION_ID`

`HEROKU_APP_NAME`

`HEROKU_API_KEY`


## Script 

If you need this non Obb Script or Make you own script with me ( Money propose Only ) - [DARK_ALPHA](https://wa.me/711421243)




## Info

**Attention:** You dont have permission to edit this script

**Special Thanks:** Vihanga YT, Nima , Sanuwa , Black Amda and Ravindu Manoj 

## Copyrights

This is the result of our team's hard work and our team owns the bot's rights and code rights. Therefore, you have no chance to change and submit our bot under any circumstances.


## ⚖️  *CYBER - X DEVELOPER TEAM* *2K23*  ⚖️

| <a href="https://github.com/darkalphaxteam"><img src="https://telegra.ph/file/c670792adfe0d44dc5a99.jpg" width=90 height=90></a> | <a href="https://github.com/chamiofficial"><img src="https://telegra.ph/file/d81e589b841d6fd5d05a1.jpg" width=90 height=90></a> | <a href="https://github.com/DarkMakerofc"><img src="https://telegra.ph/file/819659c83ab8438084234.jpg" width=90 height=90></a> | <a href="https://github.com/Niranjana45"><img src="https://telegra.ph/file/a7e379be9415cdf16c9df.jpg" width=90 height=90></a> | <a href="https://github.com/nandundilhara"><img src="https://telegra.ph/file/213c1d599c5c3a61a7bed.jpg" width=90 height=90></a> | <a href="https://github.com/Tharushaa2004"><img src="https://telegra.ph/file/976651bc865695c128228.jpg" width=90 height=90></a> |
|---|---|---|---|---|---|
| **[DARK ALPHA](https://github.com/darkalphaxteam/)**</br>Founder & Developer</br> | **[ROSHAN CHAMIKA](https://github.com/chamiofficial)**</br>CO- Owner & CO-Coder</br> | **[MR.NIMA](https://github.com/DarkMakerofc)**</br> CO-Owner & CO-Coder</br> | **[Akash Niranjana](https://github.com/Niranjana45)**</br> Beta Tester | **[Nadun Dilhara](https://github.com/nandundilhara)**</br> Bug Tester | **[Tharusha Suwahas](https://github.com/Tharushaa2004)**</br> Bug Tester |
